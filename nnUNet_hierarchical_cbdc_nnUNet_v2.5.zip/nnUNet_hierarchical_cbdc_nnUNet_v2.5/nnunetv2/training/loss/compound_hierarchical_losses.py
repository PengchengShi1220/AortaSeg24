import torch
from nnunetv2.training.loss.cldice_loss import SoftclDiceLoss
from nnunetv2.training.loss.dice import SoftDiceLoss, MemoryEfficientSoftDiceLoss
from nnunetv2.training.loss.robust_ce_loss import RobustCrossEntropyLoss, TopKLoss
from nnunetv2.training.loss.cbdice_loss import SoftcbDiceLoss
from nnunetv2.utilities.helpers import softmax_helper_dim1
from torch import nn

class DC_and_CE_HT_loss(nn.Module):
    def __init__(self, soft_dice_kwargs, ce_kwargs, target_level_dict={0: [], 1: []}, transform_levels_dict={0: [], 1: []}, weight_ce=1, weight_dice=1, ignore_label=None,
                 dice_class=SoftDiceLoss, level_epochs_list=[], hierarchical_weight_dict={}):
        """
        Weights for CE and Dice do not need to sum to one. You can set whatever you want.
        :param soft_dice_kwargs:
        :param ce_kwargs:
        :param aggregate:
        :param square_dice:
        :param weight_ce:
        :param weight_dice:
        """
        super(DC_and_CE_HT_loss, self).__init__()
        if ignore_label is not None:
            ce_kwargs['ignore_index'] = ignore_label

        self.target_level_dict = target_level_dict
        self.max_level = max(target_level_dict.keys())
        self.min_level = min(target_level_dict.keys())
        self.transform_levels_dict = transform_levels_dict
        self.weight_dice = weight_dice
        self.weight_ce = weight_ce
        self.ignore_label = ignore_label
        self.level_epochs_list = level_epochs_list
        self.hierarchical_weight_dict = hierarchical_weight_dict

        self.ce = RobustCrossEntropyLoss(**ce_kwargs)
        self.dc = dice_class(apply_nonlin=softmax_helper_dim1, **soft_dice_kwargs)

    def forward(self, net_output: torch.Tensor, target: torch.Tensor, current_epoch):
        """
        target must be b, c, x, y(, z) with c=1
        :param net_output:
        :param target:
        :return:
        """

        ce_list = []
        dc_list = []
        level_weight_list = []
        for l in range(self.max_level, self.min_level-1, -1):
            target_merged = torch.zeros_like(target).to(target.device)
            target_list = self.target_level_dict[l]
            
            # hierarchically merge target labels
            for t in range(0, len(target_list)):
                target_merged[torch.isin(target, target_list[t])] = t
            
            if l == self.max_level:
                net_output_level = net_output
            else:               
                net_output_level = transform_logits_levels(net_output_level, self.transform_levels_dict[l])

            if self.ignore_label is not None:
                assert target_merged.shape[1] == 1, 'ignore label is not implemented for one hot encoded target variables ' \
                                            '(DC_and_CE_loss)'
                mask = (target_merged != self.ignore_label).bool()
                # remove ignore label from target, replace with one of the known labels. It doesn't matter because we
                # ignore gradients in those areas anyway
                target_dice = torch.clone(target_merged)
                target_dice[target_merged == self.ignore_label] = 0
                num_fg = mask.sum()
            else:
                target_dice = target_merged
                mask = None

            dc_loss = self.dc(net_output_level, target_dice, loss_mask=mask) \
                if self.weight_dice != 0 else 0
            ce_loss = self.ce(net_output_level, target_merged[:, 0].long()) \
                if self.weight_ce != 0 and (self.ignore_label is None or num_fg > 0) else 0
            
            del target_merged
 
            dc_list.append(self.weight_dice * dc_loss)
            ce_list.append(self.weight_ce * ce_loss)

            level_weight_list.append(self.hierarchical_weight_dict[l])

        level_weight_list = torch.tensor(level_weight_list).to(target.device)
        tmp_level_weight_list = (level_weight_list / level_weight_list.sum())
        
        del net_output_level
        
        tmp_level_weight_list = tmp_level_weight_list.flip(0)
        ce_list = ce_list[::-1]
        dc_list = dc_list[::-1]

        current_max_level = len(tmp_level_weight_list) - 1
        for i in range(len(tmp_level_weight_list)):
            if current_epoch <= self.level_epochs_list[i]:
                current_max_level = i
                break
        
        res = 0
        for j in range(0, current_max_level+1):
            new_tmp_level_weight = tmp_level_weight_list[j] / tmp_level_weight_list[:current_max_level+1].sum()
            res += ce_list[j] * new_tmp_level_weight
            res += dc_list[j] * new_tmp_level_weight
        
        return res


class DC_and_CE_and_CBDC_HT_loss(nn.Module):
    def __init__(self, soft_dice_kwargs, ce_kwargs, cbdice_kwargs, target_level_dict={0: [], 1: []}, transform_levels_dict={0: [], 1: []}, weight_ce=4, weight_dice=1, weight_cbdice=3, ignore_label=None,
                 dice_class=SoftDiceLoss, level_epochs_list=[], hierarchical_weight_dict={}):

        """
        Weights for CE and Dice do not need to sum to one. You can set whatever you want.
        :param soft_dice_kwargs:
        :param ce_kwargs:
        :param cbdice_kwargs:
        :param aggregate:
        :param square_dice:
        :param weight_ce:
        :param weight_dice:
        :param weight_cbdice:
        """
        super(DC_and_CE_and_CBDC_HT_loss, self).__init__()
        if ignore_label is not None:
            ce_kwargs['ignore_index'] = ignore_label

        self.target_level_dict = target_level_dict
        self.max_level = max(target_level_dict.keys())
        self.min_level = min(target_level_dict.keys())
        self.transform_levels_dict = transform_levels_dict
        self.weight_dice = weight_dice
        self.weight_ce = weight_ce
        self.weight_cbdice = weight_cbdice
        self.ignore_label = ignore_label
        self.level_epochs_list = level_epochs_list
        self.hierarchical_weight_dict = hierarchical_weight_dict

        self.ce = RobustCrossEntropyLoss(**ce_kwargs)
        self.dc = dice_class(apply_nonlin=softmax_helper_dim1, **soft_dice_kwargs)
        self.cbdice = SoftcbDiceLoss(**cbdice_kwargs)

    def forward(self, net_output: torch.Tensor, target: torch.Tensor, current_epoch):
        """
        target must be b, c, x, y(, z) with c=1
        :param net_output:
        :param target:
        :return:
        """

        ce_list = []
        dc_list = []
        cbdice_list = []
        level_weight_list = []
        for l in range(self.max_level, self.min_level-1, -1):
            target_merged = torch.zeros_like(target).to(target.device)
            target_list = self.target_level_dict[l]
            
            # hierarchically merge target labels
            for t in range(0, len(target_list)):
                target_merged[torch.isin(target, target_list[t])] = t
            
            if l == self.max_level:
                net_output_level = net_output
            else:               
                net_output_level = transform_logits_levels(net_output_level, self.transform_levels_dict[l])

            if self.ignore_label is not None:
                assert target_merged.shape[1] == 1, 'ignore label is not implemented for one hot encoded target variables ' \
                                            '(DC_and_CE_loss)'
                mask = (target_merged != self.ignore_label).bool()
                # remove ignore label from target, replace with one of the known labels. It doesn't matter because we
                # ignore gradients in those areas anyway
                target_dice = torch.clone(target_merged)
                target_dice[target_merged == self.ignore_label] = 0
                num_fg = mask.sum()
            else:
                target_dice = target_merged
                mask = None

            dc_loss = self.dc(net_output_level, target_dice, loss_mask=mask) if self.weight_dice != 0 else 0
            ce_loss = self.ce(net_output_level, target_merged[:, 0].long()) if self.weight_ce != 0 and (self.ignore_label is None or num_fg > 0) else 0

            if l == self.max_level:
                cbdice_loss = self.weight_cbdice * self.cbdice(net_output_level, target_merged) if self.weight_cbdice != 0 else 0
            else:
                pass
            
            del target_merged
 
            dc_list.append(self.weight_dice * dc_loss)
            ce_list.append(self.weight_ce * ce_loss)

            level_weight_list.append(self.hierarchical_weight_dict[l])

        level_weight_list = torch.tensor(level_weight_list).to(target.device)
        tmp_level_weight_list = (level_weight_list / level_weight_list.sum())
        
        del net_output_level

        tmp_level_weight_list = tmp_level_weight_list.flip(0)
        ce_list = ce_list[::-1]
        dc_list = dc_list[::-1]

        current_max_level = len(tmp_level_weight_list) - 1
        for i in range(len(tmp_level_weight_list)):
            if current_epoch <= self.level_epochs_list[i]:
                current_max_level = i
                break
        
        res = 0
        ce_h = 0
        dc_h = 0
        for j in range(0, current_max_level+1):
            new_tmp_level_weight = tmp_level_weight_list[j] / tmp_level_weight_list[:current_max_level+1].sum()
            ce_h += ce_list[j] * new_tmp_level_weight
            dc_h += dc_list[j] * new_tmp_level_weight
        
        cbdc_h = cbdice_loss # cbdice loss (calculated only at the highest level)

        res = ce_h + dc_h + cbdc_h
        
        return res
