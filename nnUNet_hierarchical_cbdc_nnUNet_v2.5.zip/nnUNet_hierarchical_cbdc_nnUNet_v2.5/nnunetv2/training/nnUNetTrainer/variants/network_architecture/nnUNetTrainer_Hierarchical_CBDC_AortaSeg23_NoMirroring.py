from nnunetv2.training.nnUNetTrainer.variants.network_architecture.nnUNetTrainer_Hierarchical_CBDC_AortaSeg23 import nnUNetTrainer_Hierarchical_CBDC_AortaSeg23

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_NoMirroring(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23):
    def configure_rotation_dummyDA_mirroring_and_inital_patch_size(self):
        rotation_for_DA, do_dummy_2d_data_aug, initial_patch_size, mirror_axes = \
            super().configure_rotation_dummyDA_mirroring_and_inital_patch_size()
        mirror_axes = None
        self.inference_allowed_mirroring_axes = None
        return rotation_for_DA, do_dummy_2d_data_aug, initial_patch_size, mirror_axes
        
