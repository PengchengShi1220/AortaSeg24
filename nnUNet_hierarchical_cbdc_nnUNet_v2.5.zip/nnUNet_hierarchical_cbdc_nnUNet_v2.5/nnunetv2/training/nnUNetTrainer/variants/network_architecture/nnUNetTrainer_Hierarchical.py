import torch
import numpy as np
from time import time
from typing import List
from batchgenerators.utilities.file_and_folder_operations import join

from torch import autocast, nn
from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer
from nnunetv2.training.loss.dice import get_tp_fp_fn_tn, MemoryEfficientSoftDiceLoss
from nnunetv2.training.loss.deep_supervision_hierarchical import DeepSupervisionWrapper
from nnunetv2.training.loss.compound_hierarchical_losses import DC_and_CE_HT_loss
from nnunetv2.utilities.collate_outputs import collate_outputs

class nnUNetTrainer_Hierarchical(nnUNetTrainer):

    def make_tensors(self, lists, device):
        if not lists:
            return lists
        elif isinstance(lists[0], list):
            return [self.make_tensors(sublist, device) for sublist in lists]
        else:
            return torch.tensor(lists).to(device)

    def _build_loss(self):

        deep_supervision_scales = self._get_deep_supervision_scales()

        # we give each output a weight which decreases exponentially (division by 2) as the resolution decreases
        # this gives higher resolution outputs more weight in the loss
        weights = np.array([1 / (2 ** i) for i in range(len(deep_supervision_scales))])

        # Normalize weights so that they sum to 1
        weights = weights / weights.sum()
                
        loss_list = []
        min_target_level = min(self.target_level_dict.keys())
        min_transform_level = min(self.transform_levels_dict.keys())
        max_target_level = max(self.target_level_dict.keys())
        max_transform_level = max(self.transform_levels_dict.keys())

        for i in range(min_target_level, max_target_level+1):
            self.target_level_dict[i] = self.make_tensors(self.target_level_dict[i], self.device)
        
        for i in range(min_transform_level, max_transform_level+1):
            self.transform_levels_dict[i] = self.make_tensors(self.transform_levels_dict[i], self.device)

        for l in range(0, len(weights)):
                
            loss = DC_and_CE_HT_loss({'batch_dice': self.configuration_manager.batch_dice, 'smooth': 1e-5, 'do_bg': False, 'ddp': self.is_ddp}, {},
                                       target_level_dict=self.target_level_dict, transform_levels_dict=self.transform_levels_dict, weight_ce=1, weight_dice=1, ignore_label=self.label_manager.ignore_label, dice_class=MemoryEfficientSoftDiceLoss, level_epochs_list=self.level_epochs_list, hierarchical_weight_dict=self.hierarchical_weight_dict)

            loss_list.append(loss)

        # now wrap the loss
        loss = DeepSupervisionWrapper(loss_list, weights)
        return loss
    
    def transform_logits_levels(self, input_tensor, dst_transform_level):
        """
        Transforms tensor across different semantic levels.
        :param input_tensor: Input tensor, shape: [batch_size, channels, depth, height, width].
        :param dst_transform_level: List of lists indicating channel indices to transform.
        :return: Transformed tensor.
        """

        transformed_channels = [None] * len(dst_transform_level)

        for i, target_channels in enumerate(dst_transform_level):
            if len(target_channels) == 1:
                transformed_channels[i] = input_tensor[:, target_channels[0]:target_channels[0]+1]
            else:
                selected_channels = input_tensor[:, target_channels]
                transformed_channels[i] = torch.max(selected_channels, dim=1, keepdim=True)[0]

        output_tensor = torch.cat(transformed_channels, dim=1)

        return output_tensor

    def train_step(self, batch: dict) -> dict:
        data = batch['data']
        target = batch['target']

        data = data.to(self.device, non_blocking=True)
        if isinstance(target, list):
            target = [i.to(self.device, non_blocking=True) for i in target]
        else:
            target = target.to(self.device, non_blocking=True)

        self.optimizer.zero_grad()
        # Autocast is a little bitch.
        # If the device_type is 'cpu' then it's slow as heck and needs to be disabled.
        # If the device_type is 'mps' then it will complain that mps is not implemented, even if enabled=False is set. Whyyyyyyy. (this is why we don't make use of enabled=False)
        # So autocast will only be active if we have a cuda device.
        with autocast(self.device.type, enabled=True) if self.device.type == 'cuda' else dummy_context():
            output = self.network(data)
            # del data
            l = self.loss(output, target, self.current_epoch) # self.current_epoch

        if self.grad_scaler is not None:
            self.grad_scaler.scale(l).backward()
            self.grad_scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self.network.parameters(), 12)
            self.grad_scaler.step(self.optimizer)
            self.grad_scaler.update()
        else:
            l.backward()
            torch.nn.utils.clip_grad_norm_(self.network.parameters(), 12)
            self.optimizer.step()
        return {'loss': l.detach().cpu().numpy()}

    def validation_step(self, batch: dict) -> dict:
        data = batch['data']
        target = batch['target']

        data = data.to(self.device, non_blocking=True)
        if isinstance(target, list):
            target = [i.to(self.device, non_blocking=True) for i in target]
        else:
            target = target.to(self.device, non_blocking=True)

        # Autocast is a little bitch.
        # If the device_type is 'cpu' then it's slow as heck and needs to be disabled.
        # If the device_type is 'mps' then it will complain that mps is not implemented, even if enabled=False is set. Whyyyyyyy. (this is why we don't make use of enabled=False)
        # So autocast will only be active if we have a cuda device.
        with autocast(self.device.type, enabled=True) if self.device.type == 'cuda' else dummy_context():
            output = self.network(data)
            del data
            l = self.loss(output, target, self.current_epoch) # current_epoch=self.current_epoch

        # we only need the output with the highest output resolution
        output = output[0]
        target = target[0]

        # the following is needed for online evaluation. Fake dice (green line)
        axes = [0] + list(range(2, len(output.shape)))

        tp_hard_dict, fp_hard_dict, fn_hard_dict = {}, {}, {}
        for k in range(self.max_level, self.min_level-1, -1):
            target_merged = torch.zeros_like(target).to(target.device)
            target_list = self.target_level_dict[k]
            
            # hierarchically merge target labels
            for t in range(0, len(target_list)):
                target_merged[torch.isin(target, target_list[t])] = t

            if k == self.max_level:
                output_level = output
            else:               
                output_level = self.transform_logits_levels(output_level, self.transform_levels_dict[k])

            if self.label_manager.has_regions:
                predicted_segmentation_onehot = (torch.sigmoid(output_level) > 0.5).long()
            else:
                # no need for softmax
                output_level_seg = output_level.argmax(1)[:, None]
                predicted_segmentation_onehot = torch.zeros(output_level.shape, device=output_level.device, dtype=torch.float32)
                predicted_segmentation_onehot.scatter_(1, output_level_seg, 1)
                del output_level_seg

            if self.label_manager.has_ignore_label:
                if not self.label_manager.has_regions:
                    mask = (target_merged != self.label_manager.ignore_label).float()
                    # CAREFUL that you don't rely on target_merged after this line!
                    target_merged[target_merged == self.label_manager.ignore_label] = 0
                else:
                    mask = 1 - target_merged[:, -1:]
                    # CAREFUL that you don't rely on target_merged after this line!
                    target_merged = target_merged[:, :-1]
            else:
                mask = None

            tp, fp, fn, _ = get_tp_fp_fn_tn(predicted_segmentation_onehot, target_merged, axes=axes, mask=mask)

            tp_hard = tp.detach().cpu().numpy()
            fp_hard = fp.detach().cpu().numpy()
            fn_hard = fn.detach().cpu().numpy()
            if not self.label_manager.has_regions:
                # if we train with regions all segmentation heads predict some kind of foreground. In conventional
                # (softmax training) there needs tobe one output_level for the background. We are not interested in the
                # background Dice
                # [1:] in order to remove background
                tp_hard = tp_hard[1:]
                fp_hard = fp_hard[1:]
                fn_hard = fn_hard[1:]
        
            tp_hard_dict[k] = tp_hard
            fp_hard_dict[k] = fp_hard
            fn_hard_dict[k] = fn_hard

        return {'loss': l.detach().cpu().numpy(), 'tp_hard_dict': tp_hard_dict, 'fp_hard_dict': fp_hard_dict, 'fn_hard_dict': fn_hard_dict}

    def on_validation_epoch_end(self, val_outputs: List[dict]):
        outputs_collated = collate_outputs(val_outputs)
        tp_hard_dict = outputs_collated['tp_hard_dict']
        fp_hard_dict = outputs_collated['fp_hard_dict']
        fn_hard_dict = outputs_collated['fn_hard_dict']

        tp_dict = {}
        fp_dict = {}
        fn_dict = {}
        for level in range(self.min_level, self.max_level+1):
            tp_dict[level] = np.sum(tp_hard_dict[level], 0)
            fp_dict[level] = np.sum(fp_hard_dict[level], 0)
            fn_dict[level] = np.sum(fn_hard_dict[level], 0)

        if self.is_ddp:
            world_size = dist.get_world_size()
            for level in range(self.min_level, self.max_level+1):

                tps = [None for _ in range(world_size)]
                dist.all_gather_object(tps, tp_dict[level])
                tp_dict[level] = np.vstack([i[None] for i in tps]).sum(0)

                fps = [None for _ in range(world_size)]
                dist.all_gather_object(fps, fp_dict[level])
                fp_dict[level] = np.vstack([i[None] for i in fps]).sum(0)

                fns = [None for _ in range(world_size)]
                dist.all_gather_object(fns, fn_dict[level])
                fn_dict[level] = np.vstack([i[None] for i in fns]).sum(0)

            losses_val = [None for _ in range(world_size)]
            dist.all_gather_object(losses_val, outputs_collated['loss'])
            loss_here = np.vstack(losses_val).mean()
        else:
            loss_here = np.mean(outputs_collated['loss'])

        global_dc_per_class_dict = {}
        mean_fg_dice_dict = {}
        for level in range(self.min_level, self.max_level+1):
            global_dc_per_class_dict[level] = [i for i in [2 * i / (2 * i + j + k) for i, j, k in
                                            zip(tp_dict[level], fp_dict[level], fn_dict[level])]]
            mean_fg_dice_dict[level] = np.nanmean(global_dc_per_class_dict[level])
            self.logger.log('mean_fg_dice_level' + str(level), mean_fg_dice_dict[level], self.current_epoch)
            self.logger.log('dice_per_class_or_region_level' + str(level), global_dc_per_class_dict[level], self.current_epoch)
        
        self.logger.log('mean_fg_dice', mean_fg_dice_dict[self.max_level], self.current_epoch)
        self.logger.log('dice_per_class_or_region', global_dc_per_class_dict[self.max_level], self.current_epoch)
        self.logger.log('val_losses', loss_here, self.current_epoch)

    def on_epoch_end(self):
        self.logger.log('epoch_end_timestamps', time(), self.current_epoch)

        # todo find a solution for this stupid shit
        self.print_to_log_file('train_loss', np.round(self.logger.my_fantastic_logging['train_losses'][-1], decimals=4))
        self.print_to_log_file('val_loss', np.round(self.logger.my_fantastic_logging['val_losses'][-1], decimals=4))
        for level in range(self.min_level, self.max_level+1):
            self.print_to_log_file('Pseudo dice level' + str(level), [np.round(i, decimals=4) for i in
                                               self.logger.my_fantastic_logging['dice_per_class_or_region_level' + str(level)][-1]])
        self.print_to_log_file(
            f"Epoch time: {np.round(self.logger.my_fantastic_logging['epoch_end_timestamps'][-1] - self.logger.my_fantastic_logging['epoch_start_timestamps'][-1], decimals=2)} s")

        # handling periodic checkpointing
        current_epoch = self.current_epoch
        if (current_epoch + 1) % self.save_every == 0 and current_epoch != (self.num_epochs - 1):
            self.save_checkpoint(join(self.output_folder, 'checkpoint_latest.pth'))

        for i in range(0, len(self.level_epochs_list)):
            if current_epoch == (self.level_epochs_list[i]-1) or current_epoch == self.level_epochs_list[i]:
                self.save_checkpoint(join(self.output_folder, 'checkpoint_epoch' + str(current_epoch) + '.pth'))
        
        # tmp: TopCoW 2023 MRA:
        if current_epoch in [0, 1, 2, 3, 4, 6, 7, 10, 11, 15, 20, 30, 50, 75, 100, 150, 199]:
            self.save_checkpoint(join(self.output_folder, 'checkpoint_epoch%d.pth' % current_epoch))

        # handle 'best' checkpointing. ema_fg_dice is computed by the logger and can be accessed like this
        if self._best_ema is None or self.logger.my_fantastic_logging['ema_fg_dice'][-1] > self._best_ema:
            self._best_ema = self.logger.my_fantastic_logging['ema_fg_dice'][-1]
            self.print_to_log_file(f"Yayy! New best EMA pseudo Dice: {np.round(self._best_ema, decimals=4)}")
            self.save_checkpoint(join(self.output_folder, 'checkpoint_best.pth'))

        if self.local_rank == 0:
            self.logger.plot_progress_png(self.output_folder)

        self.current_epoch += 1
