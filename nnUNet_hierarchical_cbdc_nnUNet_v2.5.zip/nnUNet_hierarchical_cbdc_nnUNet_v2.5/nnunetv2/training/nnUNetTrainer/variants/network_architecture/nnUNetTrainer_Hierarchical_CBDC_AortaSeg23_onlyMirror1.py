from nnunetv2.training.nnUNetTrainer.variants.network_architecture.nnUNetTrainer_Hierarchical_CBDC_AortaSeg23 import nnUNetTrainer_Hierarchical_CBDC_AortaSeg23

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23):
    """
    Only mirrors along spatial axes 0 and 1 for 3D and 0 for 2D
    """
    def configure_rotation_dummyDA_mirroring_and_inital_patch_size(self):
        rotation_for_DA, do_dummy_2d_data_aug, initial_patch_size, mirror_axes = \
            super().configure_rotation_dummyDA_mirroring_and_inital_patch_size()
        patch_size = self.configuration_manager.patch_size
        dim = len(patch_size)
        if dim == 2:
            mirror_axes = (0, )
        else:
            mirror_axes = (1, )
        self.inference_allowed_mirroring_axes = mirror_axes
        return rotation_for_DA, do_dummy_2d_data_aug, initial_patch_size, mirror_axes

