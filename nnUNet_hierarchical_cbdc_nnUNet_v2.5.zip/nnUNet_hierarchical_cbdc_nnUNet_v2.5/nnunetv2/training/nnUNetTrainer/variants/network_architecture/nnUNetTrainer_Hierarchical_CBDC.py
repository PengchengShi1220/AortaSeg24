import numpy as np

from nnunetv2.training.nnUNetTrainer.variants.network_architecture.nnUNetTrainer_Hierarchical import nnUNetTrainer_Hierarchical
from nnunetv2.training.loss.dice import get_tp_fp_fn_tn, MemoryEfficientSoftDiceLoss
from nnunetv2.training.loss.deep_supervision_hierarchical import DeepSupervisionWrapper
from nnunetv2.training.loss.compound_hierarchical_losses import DC_and_CE_and_CBDC_HT_loss

class nnUNetTrainer_Hierarchical_CBDC(nnUNetTrainer_Hierarchical):

    def _build_loss(self):

        deep_supervision_scales = self._get_deep_supervision_scales()

        # we give each output a weight which decreases exponentially (division by 2) as the resolution decreases
        # this gives higher resolution outputs more weight in the loss
        weights = np.array([1 / (2 ** i) for i in range(len(deep_supervision_scales))])

        # Normalize weights so that they sum to 1
        weights = weights / weights.sum()
                
        loss_list = []
        min_target_level = min(self.target_level_dict.keys())
        min_transform_level = min(self.transform_levels_dict.keys())
        max_target_level = max(self.target_level_dict.keys())
        max_transform_level = max(self.transform_levels_dict.keys())

        for i in range(min_target_level, max_target_level+1):
            self.target_level_dict[i] = self.make_tensors(self.target_level_dict[i], self.device)
        
        for i in range(min_transform_level, max_transform_level+1):
            self.transform_levels_dict[i] = self.make_tensors(self.transform_levels_dict[i], self.device)

        lambda_cbdice = 1.0 
        lambda_dice = 1.0
        lambda_ce = lambda_dice + lambda_cbdice

        self.print_to_log_file("lambda_cbdice: %s" % str(lambda_cbdice))
        self.print_to_log_file("lambda_dice: %s" % str(lambda_dice))
        self.print_to_log_file("lambda_ce: %s" % str(lambda_ce))

        for l in range(0, len(weights)):

            loss = DC_and_CE_and_CBDC_HT_loss({'batch_dice': self.configuration_manager.batch_dice, 'smooth': 1e-5, 'do_bg': False, 'ddp': self.is_ddp}, {},
                                       {'iter_': 3, 'smooth': 1e-3},
                                       target_level_dict=self.target_level_dict, transform_levels_dict=self.transform_levels_dict, 
                                       weight_ce=lambda_ce, weight_dice=lambda_dice, weight_cbdice=lambda_cbdice, ignore_label=self.label_manager.ignore_label, dice_class=MemoryEfficientSoftDiceLoss, 
                                       level_epochs_list=self.level_epochs_list, hierarchical_weight_dict=self.hierarchical_weight_dict)
            
            loss_list.append(loss)

        # now wrap the loss
        loss = DeepSupervisionWrapper(loss_list, weights)
        return loss
