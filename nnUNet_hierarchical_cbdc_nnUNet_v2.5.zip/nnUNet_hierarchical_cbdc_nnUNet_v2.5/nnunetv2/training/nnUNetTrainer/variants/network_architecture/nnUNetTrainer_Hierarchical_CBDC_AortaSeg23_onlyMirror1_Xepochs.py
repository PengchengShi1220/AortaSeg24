import torch

from nnunetv2.training.nnUNetTrainer.variants.network_architecture.nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1 import nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_1epoch(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        """used for debugging plans etc"""
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 1

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_5epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        """used for debugging plans etc"""
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 5

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_10epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        """used for debugging plans etc"""
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 10


class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_20epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 20


class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_50epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 50


class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_100epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 100

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_200epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 200

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_250epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 250

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_500epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 500

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_1050epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 1050

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_1200epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 1200

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_2000epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 2000

    
class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_4000epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 4000


class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1_8000epochs(nnUNetTrainer_Hierarchical_CBDC_AortaSeg23_onlyMirror1):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)
        self.num_epochs = 8000
