import torch
import numpy as np
from time import time
from nnunetv2.training.logging.nnunet_logger_hierarchical import nnUNetLogger_Hierarchical
from torch import autocast, nn
from nnunetv2.training.nnUNetTrainer.variants.network_architecture.nnUNetTrainer_Hierarchical_CBDC import nnUNetTrainer_Hierarchical_CBDC

class nnUNetTrainer_Hierarchical_CBDC_AortaSeg23(nnUNetTrainer_Hierarchical_CBDC):
    def __init__(self, plans: dict, configuration: str, fold: int, dataset_json: dict, unpack_dataset: bool = True,
                 device: torch.device = torch.device('cuda')):
        """used for debugging plans etc"""
        super().__init__(plans, configuration, fold, dataset_json, unpack_dataset, device)

        # AortaSeg 23 classes dataset:
        self.target_level_dict = {}
        self.target_level_dict[1] = [[0], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]]
        self.target_level_dict[2] = [[0], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]]
        self.target_level_dict[3] = [[0], [1, 2, 3, 4, 5, 6], [7, 8, 9, 10, 11], [12, 13, 14, 15, 16, 17], [18, 19, 20, 21, 22, 23]]
        self.target_level_dict[4] = [[0], [1, 3, 5], [2, 4, 6], [7, 8], [9, 10, 11], [12, 14, 17], [13, 15, 16], [18, 20, 22], [19, 21, 23]]
        self.target_level_dict[5] = [[0], [1], [3, 5], [2], [4, 6], [7], [8], [9], [10, 11], [12, 14], [17], [13], [15, 16], [18], [20, 22], [19], [21, 23]]
        self.target_level_dict[6] = [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16], [17], [18], [19], [20], [21], [22], [23]]

        self.transform_levels_dict = {}
        self.transform_levels_dict[1] = [[0], [1, 2]]
        self.transform_levels_dict[2] = [[0], [1, 2], [3, 4]]
        self.transform_levels_dict[3] = [[0], [1, 2], [3, 4], [5, 6], [7, 8]]
        self.transform_levels_dict[4] = [[0], [1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12], [13, 14], [15, 16]]
        self.transform_levels_dict[5] = [[0], [1], [3, 5], [2], [4, 6], [7], [8], [9], [10, 11], [12, 14], [17], [13], [15, 16], [18], [20, 22], [19], [21, 23]]
        self.transform_levels_dict[6] = [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16], [17], [18], [19], [20], [21], [22], [23]]

        target_level_len_list = []
        target_level_max = max(self.target_level_dict.keys())
        for i in range(1, target_level_max+1):
            target_level_len = len(self.target_level_dict[i])
            target_level_len_list.append(target_level_len)
        self.configuration_manager.configuration["num_classes_hierarchical"] = target_level_len_list
        
        self.inclusion_level_dict = {}
        self.inclusion_level_dict[2] = []
        self.inclusion_level_dict[3] = []
        self.inclusion_level_dict[4] = []
        self.inclusion_level_dict[5] = []
        self.inclusion_level_dict[6] = []

        self.exclusion_level_dict = {}
        self.exclusion_level_dict[2] = []
        self.exclusion_level_dict[3] = []
        self.exclusion_level_dict[4] = [[7, 8]]
        self.exclusion_level_dict[5] = [[3, 4], [11, 12]]
        self.exclusion_level_dict[6] = [[4, 6], [15, 16], [20, 22], [21, 23]]
        
        self.connection_level_dict = {}
        self.connection_level_dict[2] = [[1, 2]]
        self.connection_level_dict[3] = [[1, 2], [3, 4]]
        self.connection_level_dict[4] = [[1, 2], [3, 4], [5, 6]]
        self.connection_level_dict[5] = [[1, 2], [5, 6], [7, 8], [9, 10], [13, 14], [15, 16]]
        self.connection_level_dict[6] = [[3, 5], [10, 11], [12, 14]]

        self.bti_level_dict = {"inclusion": self.inclusion_level_dict, "exclusion": self.exclusion_level_dict, "connection": self.connection_level_dict}

        self.print_to_log_file("num_classes_hierarchical: %s" % str(self.configuration_manager.configuration["num_classes_hierarchical"]))
        self.print_to_log_file("inclusion_level_dict: %s" % str(self.inclusion_level_dict))
        self.print_to_log_file("exclusion_level_dict: %s" % str(self.exclusion_level_dict))
        self.print_to_log_file("connection_level_dict: %s" % str(self.connection_level_dict))

        self.max_level = max(self.target_level_dict.keys())
        self.min_level = min(self.target_level_dict.keys())
        self.logger = nnUNetLogger_Hierarchical(min_level=self.min_level, max_level=self.max_level)

        # self.level_epochs_list = [int(i) for i in range(min_target_level-1, max_target_level)]
        level_epochs_candidate_list = [0, 1, 2, 4, 7, 11, 16, 22, 29, 37]
        max_target_level = max(self.target_level_dict.keys())
        self.level_epochs_list = level_epochs_candidate_list[:max_target_level]
        self.print_to_log_file("level_epochs_list: %s" % str(self.level_epochs_list))

        # self.hierarchical_n = 2
        self.hierarchical_K_dict = {1: 2, 2: 2, 3: 2, 4: 2, 5: 2, 6: 2}
        self.hierarchical_weight_dict = {}
        for l in self.hierarchical_K_dict:
            if l == 1:
                self.hierarchical_weight_dict[l] = self.hierarchical_K_dict[l]
            else:
                self.hierarchical_weight_dict[l] = self.hierarchical_weight_dict[l-1] * self.hierarchical_K_dict[l] 
        print("hierarchical_weight_dict: ", self.hierarchical_weight_dict)
